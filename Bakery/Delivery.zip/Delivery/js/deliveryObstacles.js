/* ==========================================================================
   BAKERY DELIVERY — DELIVERY OBSTACLES (Stage 2)
   Spawns Obs 1/4/5 into the world layer, moves them at the SAME current
   world speed the background scrolls at (including any collision
   slowdown, via deliveryWorld.getCurrentSpeed()) so nothing ever drifts
   out of sync with the road, and checks each against Meli's real
   collision hitbox every frame.

   Spawn timing is pattern-driven, not fully random — a small queue of
   the classic A/B/C/D patterns from the brief, generously spaced, with
   never more than one lane blocked at a given moment so there's always
   a way through. Spawn distance is time-based (OBSTACLE_MIN_REACTION_TIME_S
   × current speed), not just "at the viewport edge" — a narrow portrait
   screen alone would otherwise give much less warning than desktop.
   ========================================================================== */

window.BakeryDelivery = window.BakeryDelivery || {};

BakeryDelivery.deliveryObstacles = {

  els: {},
  pool: [],
  nextUid: 1,

  isRunning: false,
  isSpawning: false,
  spawnTimer: null,

  patternQueue: [],
  patternIndex: 0,

  // Hitboxes/ground-anchors measured directly from each supplied PNG's
  // actual visible content (not the full transparent-padded rectangle),
  // then tightened further inward for a forgiving arcade feel — a near
  // miss should truly not register. `type` distinguishes PHYSICAL
  // obstacles (normal collision → impact/slowdown) from ANXI obstacles
  // (Obs 2/3 — a different gameplay type entirely; see
  // triggerAnxiEncounter() and update()'s collision branch below).
  catalog: {
    'obs-1': {
      type: 'physical',
      kind: 'cone',
      asset: 'assets/obs-1.png',
      // Cone: focus on the solid base/body, not the thin tapered tip.
      hitbox: { left: 0.32, right: 0.68, top: 0.35, bottom: 0.82 },
      groundAnchor: 0.885
    },
    'obs-4': {
      type: 'physical',
      kind: 'puddle',
      asset: 'assets/obs-4.png',
      // Puddle: the central blob only — excludes the small satellite
      // droplets scattered around it, which would otherwise feel unfair.
      hitbox: { left: 0.24, right: 0.76, top: 0.44, bottom: 0.66 },
      groundAnchor: 0.719
    },
    'obs-5': {
      type: 'physical',
      kind: 'crate',
      asset: 'assets/obs-5.png',
      // Crate: slightly inside the visible edges.
      hitbox: { left: 0.30, right: 0.70, top: 0.30, bottom: 0.78 },
      groundAnchor: 0.865
    },
    'obs-2': {
      type: 'anxi',
      kind: 'anxi-a',
      asset: 'assets/obs-2.png',
      hitbox: { left: 0.28, right: 0.72, top: 0.20, bottom: 0.85 },
      groundAnchor: 0.90
    },
    'obs-3': {
      type: 'anxi',
      kind: 'anxi-b',
      asset: 'assets/obs-3.png',
      hitbox: { left: 0.28, right: 0.72, top: 0.20, bottom: 0.85 },
      groundAnchor: 0.90
    }
  },

  init() {
    this.els.worldLayer = document.getElementById('bd-delivery-world-layer');
  },

  start() {
    this.stop();
    this.isRunning = true;
    this.isSpawning = true;
    this.patternIndex = 0;
    this._buildPatternQueue();
    this._scheduleNextSpawn(1400); // a moment to get driving before the first one
  },

  stop() {
    this.isRunning = false;
    this.isSpawning = false;
    if (this.spawnTimer) {
      window.clearTimeout(this.spawnTimer);
      this.spawnTimer = null;
    }
    this.pool.forEach((o) => { if (o.el && o.el.parentNode) o.el.remove(); });
    this.pool = [];
  },

  pause() {
    this.isSpawning = false;
    if (this.spawnTimer) {
      window.clearTimeout(this.spawnTimer);
      this.spawnTimer = null;
    }
  },

  resume() {
    if (!this.isRunning) return;
    this.isSpawning = true;
    this._scheduleNextSpawn();
  },

  /** Route-aware: rebuilt every start() (which deliveryDestination.js
   *  calls once per house), so Anxi frequency and total obstacle count
   *  scale with THIS route's actual spawn window rather than being one
   *  generic queue reused everywhere. Physical obstacles stay the
   *  majority; 1 Anxi encounter on shorter routes, up to 2 on longer
   *  ones, never placed first and never clustered together. Lane
   *  alternates most of the time (making the player actually switch),
   *  with occasional closeFollow pairs (the D pattern: down-then-up or
   *  up-then-down) — still spaced well beyond LANE_CHANGE_DURATION so
   *  there's always real reaction time, and never two obstacles/Anxi
   *  overlapping in time such that both lanes are blocked at once. */
  _buildPatternQueue() {
    const cfg = BakeryDelivery.deliveryConfig;
    const dest = BakeryDelivery.deliveryDestination;
    const route = dest && cfg.DELIVERY_ROUTES[dest.currentIndex];
    const distance = route ? route.distance : 2800;

    const spawnWindowPx = Math.max(700, distance - cfg.HOUSE_SPAWN_LEAD_DISTANCE - cfg.CLEAR_APPROACH_EXTRA);
    const avgSpacingS = (cfg.OBSTACLE_SPACING_MIN_MS + cfg.OBSTACLE_SPACING_MAX_MS) / 2000;
    const avgSpacingPx = avgSpacingS * cfg.DELIVERY_WORLD_SPEED;
    const totalSlots = Math.max(2, Math.round(spawnWindowPx / avgSpacingPx));

    const anxiCount = distance >= 3000 ? 2 : 1;

    const seq = [];
    let lastLane = Math.random() < 0.5 ? 0 : 1;
    for (let i = 0; i < totalSlots; i++) {
      // Alternate lanes most of the time (per spec's "more sequences"
      // request); occasionally repeat so it doesn't feel metronomic.
      const lane = Math.random() < 0.75 ? (1 - lastLane) : lastLane;
      lastLane = lane;
      const closeFollow = i > 0 && Math.random() < 0.25;
      seq.push({ lane, closeFollow, kind: 'physical' });
    }

    // Place Anxi encounters evenly spaced through the sequence, never at
    // index 0 (never the very first thing the player sees) and never
    // adjacent to each other.
    const usedIndices = [];
    for (let a = 0; a < anxiCount; a++) {
      let idx = Math.min(seq.length - 1, Math.max(1, Math.round(((a + 1) / (anxiCount + 1)) * seq.length)));
      while (usedIndices.some((u) => Math.abs(u - idx) < 2) && idx < seq.length - 1) idx += 1;
      usedIndices.push(idx);
      seq[idx].kind = 'anxi';
      seq[idx].closeFollow = false; // Anxi never part of a tight back-to-back pair
    }

    this.patternQueue = seq;
  },

  _scheduleNextSpawn(forceDelayMs) {
    if (!this.isSpawning) return;
    const cfg = BakeryDelivery.deliveryConfig;

    let delay;
    if (typeof forceDelayMs === 'number') {
      delay = forceDelayMs;
    } else {
      const upcoming = this.patternQueue[this.patternIndex % this.patternQueue.length];
      delay = (upcoming && upcoming.closeFollow)
        ? cfg.OBSTACLE_SPACING_MIN_MS * 0.6
        : cfg.OBSTACLE_SPACING_MIN_MS + Math.random() * (cfg.OBSTACLE_SPACING_MAX_MS - cfg.OBSTACLE_SPACING_MIN_MS);
    }

    this.spawnTimer = window.setTimeout(() => {
      const spawned = this._spawnNext();
      this._scheduleNextSpawn(spawned ? undefined : cfg.OBSTACLE_SPAWN_RETRY_MS);
    }, delay);
  },

  /** @returns {boolean} whether an obstacle was actually spawned. */
  _spawnNext() {
    if (!this.patternQueue.length) return true;
    const entry = this.patternQueue[this.patternIndex % this.patternQueue.length];

    const spawnX = this._computeSpawnX();
    if (!this._isSpawnPositionValid(entry.lane, spawnX)) {
      return false; // don't advance patternIndex — the same entry is retried shortly
    }

    this.patternIndex += 1;
    this._spawnObstacle(entry.lane, entry.kind || 'physical', spawnX);
    return true;
  },

  _computeSpawnX() {
    const gameEl = document.getElementById('bd-delivery-game');
    const rect = gameEl.getBoundingClientRect();
    const meliRect = document.getElementById('bd-delivery-meli').getBoundingClientRect();
    const meliLocalX = (meliRect.left - rect.left) + meliRect.width / 2;

    const cfg = BakeryDelivery.deliveryConfig;
    const currentSpeed = BakeryDelivery.deliveryWorld.getCurrentSpeed() || cfg.DELIVERY_WORLD_SPEED;
    const minReactionPx = cfg.OBSTACLE_MIN_REACTION_TIME_S * currentSpeed;

    return Math.max(rect.width, meliLocalX + minReactionPx);
  },

  _isSpawnPositionValid(lane, spawnX) {
    const cfg = BakeryDelivery.deliveryConfig;
    for (const o of this.pool) {
      const dx = Math.abs(spawnX - o.x);
      const minGap = (o.lane === lane) ? cfg.OBSTACLE_MIN_SAME_LANE_GAP_PX : cfg.OBSTACLE_MIN_DIFF_LANE_GAP_PX;
      if (dx < minGap) return false;
    }
    return this._isClearOfDestinationZone(spawnX);
  },

  _isClearOfDestinationZone(spawnX) {
    const dest = BakeryDelivery.deliveryDestination;
    if (!dest || !dest.house) return true;
    const cfg = BakeryDelivery.deliveryConfig;
    const houseCenterX = dest.house.x + (dest.house.widthPx || 200) * 0.5;
    return Math.abs(spawnX - houseCenterX) >= cfg.DESTINATION_CLEAR_ZONE_PX;
  },


  _pickTypeKey(kind) {
    const keys = Object.keys(this.catalog).filter((k) => this.catalog[k].type === kind);
    return keys[Math.floor(Math.random() * keys.length)];
  },

  _spawnObstacle(lane, kind, spawnX) {
    const typeKey = this._pickTypeKey(kind || 'physical');
    const meta = this.catalog[typeKey];

    const el = document.createElement('img');
    el.src = meta.asset;
    el.alt = '';
    el.className = 'bd-delivery-obstacle' + (meta.type === 'anxi' ? ' bd-delivery-obstacle-anxi' : '');
    el.draggable = false;
    this.els.worldLayer.appendChild(el);

    this.pool.push({
      uid: this.nextUid++,
      typeKey,
      meta,
      lane,
      el,
      x: spawnX,
      alreadyHit: false,
      nearTriggered: false
    });
  },

  /** @param {number} dt seconds since last frame */
  update(dt) {
    if (!this.isRunning) return;

    const world = BakeryDelivery.deliveryWorld;
    const meli = BakeryDelivery.deliveryMeli;
    const dx = world.getCurrentSpeed() * dt;
    const meliHitbox = meli.getHitboxRect();

    for (let i = this.pool.length - 1; i >= 0; i--) {
      const o = this.pool[i];
      o.x -= dx;
      this._applyObstaclePosition(o);

      if (o.meta.type === 'anxi') {
        // Keeps the non-blocking speech bubble (if this obstacle is
        // currently showing one) visually attached to him as he scrolls
        // — a no-op for every other obstacle, and a no-op here too if
        // he isn't the bubble's current owner.
        BakeryDelivery.anxiDistraction.updateDeliveryNearPosition(o);
      }

      if (!o.alreadyHit) {
        // Change 3 — "passing near" Anxi (lane-independent, horizontal
        // proximity only) is a completely separate, non-blocking signal
        // from an actual collision below. Checked first so it can fire
        // even when Meli is in the other lane and will never collide at
        // all — exactly the "drove past without colliding" case.
        if (o.meta.type === 'anxi' && !o.nearTriggered) {
          const anxiHb = this._getObstacleHitboxRect(o);
          const anxiCenterX = (anxiHb.left + anxiHb.right) / 2;
          const meliCenterX = (meliHitbox.left + meliHitbox.right) / 2;
          const nearRadius = BakeryDelivery.deliveryConfig.DELIVERY_ANXI_NEAR_RADIUS_PX;
          if (Math.abs(anxiCenterX - meliCenterX) <= nearRadius) {
            o.nearTriggered = true;
            BakeryDelivery.deliveryAnxi.showNear(o);
          }
        }

        // Lane-authoritative collision: when Meli is settled in a lane,
        // an obstacle in the OTHER lane can never collide, full stop —
        // checked BEFORE any hitbox math, regardless of what the
        // transparent-padded rectangles might visually suggest. While
        // she's mid-glide between lanes her logical lane index is
        // ambiguous by definition, so real rendered-hitbox overlap is
        // the correct (and only) test during that brief window.
        const laneMatches = meli.isGliding || (meli.currentLane === o.lane);

        if (laneMatches) {
          const hb = this._getObstacleHitboxRect(o);
          if (this._rectsOverlap(hb, meliHitbox)) {
            o.alreadyHit = true; // this specific obstacle can never hit again
            if (o.meta.type === 'anxi') {
              // Edge case: if the non-blocking bubble was still showing
              // for THIS exact obstacle, remove it immediately — the two
              // must never be visible at the same time.
              BakeryDelivery.anxiDistraction.hideDeliveryNear(o.uid);
              this.triggerAnxiEncounter(o);
            } else {
              BakeryDelivery.deliveryGameplay.onObstacleCollision(o);
            }
          }
        }
      }

      const elWidth = o.el.getBoundingClientRect().width || 0;
      if (o.x + elWidth < -40) {
        if (o.meta.type === 'anxi') {
          BakeryDelivery.anxiDistraction.hideDeliveryNear(o.uid); // never let the bubble outlive the Anxi it belongs to
        }
        this._removeObstacle(o);
      }
    }
  },

  _applyObstaclePosition(o) {
    const world = BakeryDelivery.deliveryWorld;
    const laneT = o.lane; // discrete — obstacles don't glide between lanes
    const groundY = world.containerHeight * (
      world.laneYFraction.upper + (world.laneYFraction.lower - world.laneYFraction.upper) * laneT
    );

    const cfg = BakeryDelivery.deliveryConfig;
    const scale = cfg.OBSTACLE_SCALE_UPPER + (cfg.OBSTACLE_SCALE_LOWER - cfg.OBSTACLE_SCALE_UPPER) * laneT;

    const elHeight = o.el.offsetHeight || 1;
    const topPx = groundY - elHeight * o.meta.groundAnchor * scale;

    o.el.style.transform = `translate(${o.x}px, ${topPx}px) scale(${scale})`;
    // Lower/front-lane obstacles paint above upper/back-lane ones.
    o.el.style.zIndex = String(2 + laneT);
  },

  _getObstacleHitboxRect(o) {
    const rect = o.el.getBoundingClientRect();
    const hb = o.meta.hitbox;
    return {
      left: rect.left + rect.width * hb.left,
      right: rect.left + rect.width * hb.right,
      top: rect.top + rect.height * hb.top,
      bottom: rect.top + rect.height * hb.bottom
    };
  },

  _rectsOverlap(a, b) {
    return a.left < b.right && a.right > b.left && a.top < b.bottom && a.bottom > b.top;
  },

  _removeObstacle(o) {
    const idx = this.pool.indexOf(o);
    if (idx !== -1) this.pool.splice(idx, 1);
    if (o.el && o.el.parentNode) o.el.remove();
  },

  // ------------------------------------------------------------------
  // ANXI ENCOUNTER (direct collision — Change 4)
  // Deliberately NOT the physical crash feedback (no triggerImpact(),
  // no wobble/jerk/tilt) — Anxi isn't a road object Meli crashes into.
  // Passing NEAR Anxi without colliding is handled separately, earlier
  // in update()'s collision loop above, and never reaches this function
  // at all.
  // ------------------------------------------------------------------

  triggerAnxiEncounter(o) {
    o.el.classList.add('bd-delivery-anxi-emphasis');
    window.setTimeout(() => {
      if (o.el) o.el.classList.remove('bd-delivery-anxi-emphasis');
    }, 400);

    BakeryDelivery.deliveryAnxi.triggerCollision();
  }
};
