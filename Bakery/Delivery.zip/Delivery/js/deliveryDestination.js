/* ==========================================================================
   BAKERY DELIVERY — DELIVERY DESTINATION (Stage 3: 5 houses)
   Owns the route/arrival state machine, completely separate from
   deliveryObstacles.js — the destination house is scenery the player
   arrives AT, never something Meli can collide with. Kept architecturally
   distinct (worldObjects.obstacles vs. worldObjects.destination, in
   spirit) so Stage 4's "return to a previous house" can build on this
   without touching the obstacle system at all.

   mode progression per house:
     driving → arriving → atDestination → delivering → confirming
     → transitioning → (driving again, next house) → … → complete

   Route progress is DISTANCE-based (world px actually travelled, via
   deliveryWorld.getCurrentSpeed()*dt), never a timer — a collision's
   temporary slowdown simply makes that distance accumulate slower, which
   is already exactly correct with no special-casing needed.
   ========================================================================== */

window.BakeryDelivery = window.BakeryDelivery || {};

BakeryDelivery.deliveryDestination = {

  els: {},

  mode: 'driving',
  currentIndex: 0,          // 0-based into DELIVERY_ROUTES
  segmentDistance: 0,
  completedCount: 0,        // successfully DELIVERED (correct lane)
  lastDeliveredDestination: 0, // 1-based — reserved for Stage 4's "return"
  _laneDecision: null,      // null | 'correct' | 'wrong' — decided once per arrival
  _deliveryTriggered: false, // Change 2 — guards the marker-passthrough trigger against double-firing

  house: null,               // { x, widthPx } while a house exists on screen
  _ctaHandled: false,
  _stateTimer: null,

  deliveryElapsedMs: 0,      // DEV-ONLY stopwatch, never a real countdown

  init() {
    this.els.layer = document.getElementById('bd-delivery-destination-layer');
    this.els.houseImg = document.getElementById('bd-delivery-house-img');
    this.els.marker = document.getElementById('bd-delivery-marker');
    this.els.destinationIcon = document.getElementById('bd-delivery-destination-icon');
    this.els.ctaBtn = document.getElementById('bd-delivery-cta-btn');

    this.els.progressIcons = Array.from(document.querySelectorAll('.bd-delivery-progress-icon'));
    this.els.progressText = document.getElementById('bd-delivery-progress-text');
    this.els.elapsedReadout = document.getElementById('bd-delivery-elapsed');

    this.els.completionPanel = document.getElementById('bd-delivery-completion-panel');
    this.els.completionBtn = document.getElementById('bd-delivery-completion-btn');
    this.els.laneControls = document.querySelector('.bd-delivery-lane-controls');

    this.els.ctaBtn.addEventListener('click', () => this._handleDeliverClick());

    /* TEMPORARY DEVELOPMENT ENTRY — REMOVE/CONNECT LATER
       Console-only: BakeryDelivery.goToDeliveryDestination(1..5) jumps
       straight to that house for testing, without a second gameplay
       implementation — it just fast-forwards this same state machine. */
    if (BakeryDelivery.DEV_MODE) {
      window.goToDeliveryDestination = (n) => this._devGoToDestination(n);
    }
  },

  reset() {
    this.mode = 'driving';
    this.currentIndex = 0;
    this.segmentDistance = 0;
    this.completedCount = 0;
    this.lastDeliveredDestination = 0;
    this._deliveryTriggered = false;
    this._laneDecision = null;
    this.deliveryElapsedMs = 0;
    this._ctaHandled = false;
    this._clearStateTimer();
    this._hideHouse();
    this._updateProgressUI();
    this.els.completionPanel.classList.remove('bd-active');
    if (this.els.laneControls) this.els.laneControls.classList.remove('bd-delivery-lane-controls-disabled');
    BakeryDelivery.deliveryMeli.setMoving(true);
    this._applySegmentSpeedMultiplier();
    this._updateDestinationHudIcon();
  },

  /** @param {number} dt seconds since last frame */
  update(dt) {
    this.deliveryElapsedMs += dt * 1000;
    if (BakeryDelivery.deliveryConfig.DELIVERY_DEBUG) this._updateElapsedReadout();

    const cfg = BakeryDelivery.deliveryConfig;
    const route = cfg.DELIVERY_ROUTES[this.currentIndex];
    if (!route) return; // all five delivered — nothing left to drive toward

    if (this.mode === 'driving') {
      this.segmentDistance += BakeryDelivery.deliveryWorld.getCurrentSpeed() * dt;

      const stopSpawnAt = route.distance - cfg.HOUSE_SPAWN_LEAD_DISTANCE - cfg.CLEAR_APPROACH_EXTRA;
      if (this.segmentDistance >= stopSpawnAt) {
        BakeryDelivery.deliveryObstacles.pause(); // stop NEW spawns; existing ones still clear naturally
      }

      if (this.segmentDistance >= route.distance - cfg.HOUSE_SPAWN_LEAD_DISTANCE) {
        this._spawnHouse(route);
        this.mode = 'arriving';
      }
    } else if (this.mode === 'arriving') {
      this._updateHousePosition(dt);

      // Pure touch detection — no separate pre-computed lane decision
      // anymore, and no requirement to fully stop first. The marker
      // itself (positioned at the REQUIRED lane's road level) is the
      // single source of truth: the instant Meli's hitbox genuinely
      // touches it, delivery registers, at whatever speed she's
      // currently driving. If she's in the wrong lane she simply can't
      // touch it — no separate "wrong" snapshot needed.
      if (!this._deliveryTriggered && this._isMarkerTouchingMeli()) {
        this._registerDelivery();
      }

      if (!this._deliveryTriggered) {
        const width = this.house ? this.house.widthPx : 0;
        if (this.house && this.house.x + width < -120) {
          this._showMissedFeedback();
          BakeryDelivery.deliveryObstacles.start(); // fresh queue for the next segment — safe here, nothing is still in flight from this one
          this._beginNextSegment();
        }
      }
    } else if (this.mode === 'transitioning') {
      this._updateHousePosition(dt);
      const width = this.house ? this.house.widthPx : 0;
      if (this.house && this.house.x + width < -120) {
        this._beginNextSegment();
      }
    }
    // atDestination / delivering / confirming: house holds its fixed
    // position (world speed is already 0); those phases advance on
    // their own short timers, not per-frame distance/position logic.
  },

  // ------------------------------------------------------------------
  // HOUSE SPAWN / MOVEMENT
  // ------------------------------------------------------------------

  _spawnHouse(route) {
    this._laneDecision = null;
    this._deliveryTriggered = false;
    this.els.houseImg.src = route.house;
    this.els.layer.classList.add('bd-active');

    const gameRect = document.getElementById('bd-delivery-game').getBoundingClientRect();
    const widthPx = this.els.houseImg.getBoundingClientRect().width || 200;

    this.house = {
      x: gameRect.width + widthPx * 0.6,
      widthPx
    };

    this._showMarker();
    this._updateHousePosition(0);
  },

  _updateHousePosition(dt) {
    if (!this.house) return;
    const world = BakeryDelivery.deliveryWorld;

    if (dt > 0) {
      this.house.x -= world.getCurrentSpeed() * dt;
    }

    const imageFraction = BakeryDelivery.deliveryConfig.HOUSE_IMAGE_Y_FRACTION;
    const groundYFraction = (imageFraction - world.cropTopFraction) / (1 - world.cropTopFraction);
    const groundY = world.containerHeight * groundYFraction;

    const elHeight = this.els.houseImg.getBoundingClientRect().height || 1;
    const anchorRatio = BakeryDelivery.deliveryConfig.HOUSE_GROUND_ANCHOR_RATIO;
    const topPx = groundY - elHeight * anchorRatio;

    this.els.houseImg.style.transform = `translate(${Math.round(this.house.x)}px, ${Math.round(topPx)}px)`;
    this._positionMarkerAndCta();
  },

  /** Where the house's LEFT edge should come to rest — Meli stays
   *  slightly left of the house, never overlapping it. */
  _computeTargetStopX() {
    const meliRect = document.getElementById('bd-delivery-meli').getBoundingClientRect();
    const gameRect = document.getElementById('bd-delivery-game').getBoundingClientRect();
    const meliLocalX = (meliRect.left - gameRect.left) + meliRect.width * 0.75;
    const houseWidth = this.house ? this.house.widthPx : 200;
    return meliLocalX + houseWidth * 0.18;
  },

  /** Change 2 — forgiving trigger check: is Meli's fixed screen position
   *  currently within the marker's trigger radius? Reuses the marker's
   *  own on-screen position (already updated every frame by
   *  _positionMarkerAndCta()), so this stays correct at any speed/segment
   *  without any extra bookkeeping. */
  /** The single source of truth for "did Meli actually deliver this
   *  one": both horizontal proximity to the marker AND being genuinely
   *  in the marker's own lane (checked live, every frame — not a single
   *  early snapshot that could go stale if she changes lanes after it
   *  was taken). This replaces the old separate pre-computed
   *  "correct"/"wrong" lane decision, which could permanently lock out
   *  delivery even if Meli later drove right through the visible
   *  marker. */
  _isMarkerTouchingMeli() {
    const route = BakeryDelivery.deliveryConfig.DELIVERY_ROUTES[this.currentIndex];
    if (!route) return false;

    const meliLane = BakeryDelivery.deliveryMeli.getVisualLaneRounded();
    if (meliLane !== route.lane) return false;

    const gameRect = document.getElementById('bd-delivery-game').getBoundingClientRect();
    const meliRect = document.getElementById('bd-delivery-meli').getBoundingClientRect();
    const meliCenterX = (meliRect.left - gameRect.left) + meliRect.width * 0.5;

    const markerRect = this.els.marker.getBoundingClientRect();
    const markerCenterX = (markerRect.left - gameRect.left) + markerRect.width * 0.5;

    const radius = BakeryDelivery.deliveryConfig.MARKER_TRIGGER_RADIUS_PX;
    return Math.abs(markerCenterX - meliCenterX) <= radius;
  },

  /** Registers exactly one delivery, guarded so it can never double-fire
   *  for the same house — then reuses the EXISTING confirmation banner /
   *  timing / next-segment flow unchanged. */
  _registerDelivery() {
    if (this._deliveryTriggered) return;
    this._deliveryTriggered = true;
    this._hideMarker();
    this._showConfirmation();
  },


  _hideHouse() {
    this.house = null;
    this.els.layer.classList.remove('bd-active');
    this._hideMarker();
    this._hideCta();
  },

  // ------------------------------------------------------------------
  // ARRIVAL SETTLE / CTA
  // ------------------------------------------------------------------

  _settleAtDestination() {
    this.mode = 'atDestination';
    BakeryDelivery.deliveryMeli.setMoving(false);
    BakeryDelivery.deliveryObstacles.stop(); // fully clear — no stray obstacle can ever reach this moment
    this._showCta();
    if (this.els.laneControls) this.els.laneControls.classList.add('bd-delivery-lane-controls-disabled');
  },

  controlsEnabled() {
    return this.mode === 'driving' || this.mode === 'arriving' || this.mode === 'transitioning';
  },

  _handleDeliverClick() {
    if (this.mode !== 'atDestination' || this._ctaHandled) return;
    this._ctaHandled = true;
    this.mode = 'delivering';
    this._hideCta();

    this._clearStateTimer();
    this._stateTimer = window.setTimeout(() => {
      this._showConfirmation();
    }, BakeryDelivery.deliveryConfig.DELIVERY_MICRO_ANIM_MS);
  },

  _showConfirmation() {
    this.mode = 'confirming';
    this.completedCount += 1;
    this.lastDeliveredDestination = this.currentIndex + 1;
    this._updateProgressUI();
    this._showConfirmationBanner();

    this._clearStateTimer();
    this._stateTimer = window.setTimeout(() => {
      this._startTransition();
    }, BakeryDelivery.deliveryConfig.DELIVERY_CONFIRM_MS);
  },

  _startTransition() {
    this._hideConfirmationBanner();
    this._hideMarker();

    this.mode = 'transitioning';
    this._ctaHandled = false;

    BakeryDelivery.deliveryMeli.setMoving(true);
    BakeryDelivery.deliveryObstacles.start(); // fresh spawn queue for the next route
    BakeryDelivery.deliveryWorld.setSpeedTarget(1, BakeryDelivery.deliveryConfig.NEXT_ROUTE_TRANSITION_MS);
    if (this.els.laneControls) this.els.laneControls.classList.remove('bd-delivery-lane-controls-disabled');
  },

  /** Called once a house (delivered OR missed) has fully scrolled past.
   *  The single place that decides whether another segment begins or
   *  the whole route is finished — regardless of which path got here.
   *  Does NOT touch obstacle spawning itself: the delivered path already
   *  restarted it back in _startTransition() (restarting it again here
   *  would wipe out anything that already spawned during that window);
   *  the missed path restarts it explicitly just before calling this. */
  _beginNextSegment() {
    this.currentIndex += 1;
    this.segmentDistance = 0;
    this._laneDecision = null;
    this._hideHouse();

    if (this.currentIndex >= BakeryDelivery.deliveryConfig.DELIVERY_ROUTES.length) {
      this._finishRoute();
      return;
    }

    this.mode = 'driving';
    this._applySegmentSpeedMultiplier();
    this._updateDestinationHudIcon();
    if (this.els.laneControls) this.els.laneControls.classList.remove('bd-delivery-lane-controls-disabled');
  },

  /** Progressive difficulty — one multiplier per segment, centralized in
   *  deliveryConfig.DELIVERY_SPEED_MULTIPLIERS. Falls back to the last
   *  configured value if the array is ever shorter than the route list. */
  _applySegmentSpeedMultiplier() {
    const mults = BakeryDelivery.deliveryConfig.DELIVERY_SPEED_MULTIPLIERS;
    const m = mults[this.currentIndex] ?? mults[mults.length - 1] ?? 1;
    BakeryDelivery.deliveryWorld.setSegmentMultiplier(m);
  },

  /** All 4 destinations have been passed (delivered or missed) — decide
   *  success vs. the new "incomplete" failure, reusing the SAME shared
   *  failure panel/retry flow as the timer/lives failures. */
  _finishRoute() {
    const total = BakeryDelivery.deliveryConfig.DELIVERY_ROUTES.length;
    if (this.completedCount >= total) {
      this._showCompletion();
    } else {
      BakeryDelivery.deliveryGameplay.handleRouteIncomplete(this.completedCount, total);
    }
  },

  /* TEMPORARY MISSED-DELIVERY TOAST — small, non-blocking, auto-dismiss */
  _showMissedFeedback() {
    const toast = document.createElement('div');
    toast.className = 'bd-delivery-missed-toast';
    toast.textContent = '¡PEDIDO NO ENTREGADO!';
    this.els.layer.parentNode.appendChild(toast);
    window.setTimeout(() => { if (toast.parentNode) toast.remove(); }, 1800);
  },

  // ------------------------------------------------------------------
  // MARKER / CTA POSITIONING — TEMPORARY DELIVERY MARKER — REPLACE WITH
  // FINAL ASSET LATER
  // ------------------------------------------------------------------

  _showMarker() {
    this.els.marker.classList.add('bd-active');
  },
  _hideMarker() {
    this.els.marker.classList.remove('bd-active');
  },
  _showCta() {
    this.els.ctaBtn.classList.add('bd-active');
  },
  _hideCta() {
    this.els.ctaBtn.classList.remove('bd-active');
  },

  _positionMarkerAndCta() {
    if (!this.house) return;
    const gameRect = document.getElementById('bd-delivery-game').getBoundingClientRect();
    const houseRect = this.els.houseImg.getBoundingClientRect();
    const world = BakeryDelivery.deliveryWorld;
    const route = BakeryDelivery.deliveryConfig.DELIVERY_ROUTES[this.currentIndex];

    const centerX = (houseRect.left - gameRect.left) + houseRect.width / 2;

    // The marker sits ON THE ROAD, at the Y of whichever lane this
    // delivery actually requires (route.lane) — the SAME upper/lower
    // fraction Meli and obstacles use for that lane. This is what makes
    // "touch the marker" and "be in the correct lane" the same physical
    // fact instead of two separate checks that can disagree.
    const laneY = (route && route.lane === 0) ? world.laneYFraction.upper : world.laneYFraction.lower;
    const groundY = world.containerHeight * laneY;

    this.els.marker.style.left = `${centerX}px`;
    this.els.marker.style.top = `${groundY}px`;

    this.els.ctaBtn.style.left = `${centerX}px`;
    this.els.ctaBtn.style.top = `${(houseRect.bottom - gameRect.top) + 14}px`;
  },

  // ------------------------------------------------------------------
  // PROGRESS UI (check1.png / uncheck1.png + N / total)
  // ------------------------------------------------------------------

  /** Keeps the HUD's small "DESTINO" icon in sync with whichever house
   *  the world will actually spawn next — reads the exact same
   *  DELIVERY_ROUTES[currentIndex] the world's own _spawnHouse() uses,
   *  so the two can never show a different destination from each other. */
  _updateDestinationHudIcon() {
    const route = BakeryDelivery.deliveryConfig.DELIVERY_ROUTES[this.currentIndex];
    if (route && this.els.destinationIcon) {
      this.els.destinationIcon.src = route.house;
    }
  },

  _updateProgressUI() {
    this.els.progressIcons.forEach((img, i) => {
      img.src = i < this.completedCount
        ? BakeryDelivery.assets.deliveryMarks.check
        : BakeryDelivery.assets.deliveryMarks.uncheck;
    });
    this.els.progressText.textContent =
      `${this.completedCount} / ${BakeryDelivery.deliveryConfig.DELIVERY_ROUTES.length}`;
  },

  _showConfirmationBanner() {
    let banner = this._confirmBannerEl;
    if (!banner) {
      banner = document.createElement('div');
      banner.className = 'bd-delivery-confirm-banner';
      banner.innerHTML = '<span class="bd-delivery-confirm-check">✓</span> PEDIDO ENTREGADO';
      this.els.layer.parentNode.appendChild(banner);
      this._confirmBannerEl = banner;
    }
    banner.classList.add('bd-active');
  },

  _hideConfirmationBanner() {
    if (this._confirmBannerEl) this._confirmBannerEl.classList.remove('bd-active');
  },

  // ------------------------------------------------------------------
  // TEMPORARY COMPLETION STATE — Stage 4 replaces this with the real
  // Anxi-doubt-aware ending.
  // ------------------------------------------------------------------

  _showCompletion() {
    this.mode = 'complete';
    BakeryDelivery.audioSystem.stopAll(); // level completely finished
    BakeryDelivery.deliveryTimer.stop(); // success takes priority — no timeout can fire after this
    BakeryDelivery.deliveryGameplay.stopDelivery(); // and no stray collision can fire a lives failure after this either
    this.els.completionPanel.classList.add('bd-active');
    BakeryDelivery.deliveryMeli.setMoving(false);
  },

  // ------------------------------------------------------------------
  // DEV HELPERS
  // ------------------------------------------------------------------

  _clearStateTimer() {
    if (this._stateTimer) {
      window.clearTimeout(this._stateTimer);
      this._stateTimer = null;
    }
  },

  _updateElapsedReadout() {
    const totalSec = Math.floor(this.deliveryElapsedMs / 1000);
    const m = Math.floor(totalSec / 60).toString().padStart(2, '0');
    const s = (totalSec % 60).toString().padStart(2, '0');
    this.els.elapsedReadout.textContent = `ELAPSED: ${m}:${s}`;
    this.els.elapsedReadout.style.display = 'block';
  },

  /* TEMPORARY DEVELOPMENT ENTRY — REMOVE/CONNECT LATER */
  _devGoToDestination(n) {
    const idx = Math.max(1, Math.min(BakeryDelivery.deliveryConfig.DELIVERY_ROUTES.length, n)) - 1;
    this._clearStateTimer();
    this._hideHouse();
    this.els.completionPanel.classList.remove('bd-active');
    this._hideConfirmationBanner();
    this.currentIndex = idx;
    this.completedCount = idx;
    this._laneDecision = null;
    this._deliveryTriggered = false;
    this.segmentDistance = BakeryDelivery.deliveryConfig.DELIVERY_ROUTES[idx].distance
      - BakeryDelivery.deliveryConfig.HOUSE_SPAWN_LEAD_DISTANCE - 50;
    this.mode = 'driving';
    this._ctaHandled = false;
    this._applySegmentSpeedMultiplier();
    this._updateDestinationHudIcon();
    BakeryDelivery.deliveryMeli.setMoving(true);
    BakeryDelivery.deliveryObstacles.pause();
    this._updateProgressUI();
  }
};
